<h1>ablublé</h1>
<?php /**PATH C:\Users\nicole.fsaraiva\Documents\dbvivabem\vivabem\resources\views/site/modalidade.blade.php ENDPATH**/ ?>