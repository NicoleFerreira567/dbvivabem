<h1>teste</h1>
<?php /**PATH C:\Users\nicole.fsaraiva\Documents\dbvivabem\vivabem\resources\views/site/noticia.blade.php ENDPATH**/ ?>