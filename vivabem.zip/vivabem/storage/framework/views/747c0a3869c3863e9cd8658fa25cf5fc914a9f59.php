<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo $__env->yieldContent('title'); ?> - Academia </title>
   <link rel="stylesheet" href="<?php echo e(asset('css/estilo.css')); ?>">
</head>
<body>
<nav class="menu">
    <img src="" alt="">
<ul>
<li><a href="<?php echo e(url('/')); ?>">home</a></li>
<li><a href="<?php echo e(url('/sobre')); ?>">sobre</a></li>
<li><a href="<?php echo e(url('/modalidade')); ?>">modalidade</a></li>
<li><a href="<?php echo e(url('/treino')); ?>">treino</a></li>
<li><a href="<?php echo e(url('/noticia')); ?>">noticia</a></li>
<li><a href="<?php echo e(url('/contato')); ?>">contato</a></li>
</ul>
</nav>

<main class="conteiner">
<?php echo $__env->yieldContent('conteudo'); ?>
</main>

<!--area do banner--




<footer>
    <h2>blablublé</h2>
</footer>
<!--Script-->
</body>
</html>
<?php /**PATH C:\Users\nicole.fsaraiva\Documents\dbvivabem\vivabem\resources\views/layout/layout.blade.php ENDPATH**/ ?>