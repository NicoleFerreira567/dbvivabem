<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> @yield('title') - Academia </title>
   <link rel="stylesheet" href="{{ asset('css/estilo.css') }}">
</head>
<body>
<nav class="menu">
    <img src="" alt="">
<ul>
<li><a href="{{ url('/') }}">home</a></li>
<li><a href="{{ url('/sobre') }}">sobre</a></li>
<li><a href="{{ url('/modalidade') }}">modalidade</a></li>
<li><a href="{{ url('/treino') }}">treino</a></li>
<li><a href="{{ url('/noticia') }}">noticia</a></li>
<li><a href="{{ url('/contato') }}">contato</a></li>
</ul>
</nav>

<main class="conteiner">
@yield('conteudo')
</main>

<!--area do banner--




<footer>
    <h2>blablublé</h2>
</footer>
<!--Script-->
</body>
</html>
